package divingcalculations;

/**
 * Write a description of class Formulas here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DiveFormulas {


}
